<template>
  <div class="footer">
    <span> ----footer---- </span>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.footer{
    width: 100%;
    /* background-color: #626973; */
    color: #333;
    text-align: center;
    line-height: 60px;
}
</style>